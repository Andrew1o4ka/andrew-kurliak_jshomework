const total = 100;
let ordered = 50;


ordered = 20;

let q = ordered < total ? "На складі недостатньо товарів!" : "Замовлення оформлено, з вами зв'яжеться менеджер";
console.log(q);



 ordered = 80;

let r = ordered < total ? "На складі недостатньо товарів!" : "Замовлення оформлено, з вами зв'яжеться менеджер";
console.log(r);

 ordered = 130;
let j = ordered < total ? "На складі недостатньо товарів!" : "Замовлення оформлено, з вами зв'яжеться менеджер";
console.log(j);


